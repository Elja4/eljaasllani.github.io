<?php
// UPLOADS API
require_once __DIR__ . '/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// Override content type for file uploads
header('Content-Type: application/json');

switch ($action) {

    // POST /uploads.php?action=upload
    case 'upload':
        if ($method !== 'POST') respond(['error' => 'Method not allowed'], 405);
        $user = requireAuth();
        $db   = getDB();

        $ticketId  = (int)($_POST['ticket_id'] ?? 0);
        $messageId = !empty($_POST['message_id']) ? (int)$_POST['message_id'] : null;

        if (!$ticketId) respond(['error' => 'Ticket ID required'], 422);
        if (empty($_FILES['file'])) respond(['error' => 'No file uploaded'], 422);

        // Verify ticket exists and user has access
        $stmt = $db->prepare("SELECT * FROM tickets WHERE id = ?");
        $stmt->execute([$ticketId]);
        $ticket = $stmt->fetch();

        if (!$ticket) respond(['error' => 'Ticket not found'], 404);
        if ($user['role'] === 'user' && $ticket['user_id'] != $user['id']) {
            respond(['error' => 'Forbidden'], 403);
        }

        $file         = $_FILES['file'];
        $originalName = basename($file['name']);
        $fileSize     = $file['size'];
        $fileTmp      = $file['tmp_name'];
        $fileError    = $file['error'];

        if ($fileError !== UPLOAD_ERR_OK) {
            respond(['error' => 'Upload error code: ' . $fileError], 422);
        }

        // Max 10MB
        if ($fileSize > 10 * 1024 * 1024) {
            respond(['error' => 'File too large. Max 10MB allowed.'], 422);
        }

        // Allowed types
        $allowedTypes = [
            'image/jpeg', 'image/png', 'image/gif', 'image/webp',
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'text/plain',
            'application/zip',
        ];

        $finfo    = finfo_open(FILEINFO_MIME_TYPE);
        $fileType = finfo_file($finfo, $fileTmp);
        finfo_close($finfo);

        if (!in_array($fileType, $allowedTypes)) {
            respond(['error' => 'File type not allowed.'], 422);
        }

        // Generate unique filename
        $ext      = pathinfo($originalName, PATHINFO_EXTENSION);
        $filename = uniqid('file_', true) . '.' . $ext;
        $uploadDir = __DIR__ . '/uploads/';
        $uploadPath = $uploadDir . $filename;

        if (!move_uploaded_file($fileTmp, $uploadPath)) {
            respond(['error' => 'Failed to save file'], 500);
        }

        // Save to database
        $stmt = $db->prepare("
            INSERT INTO attachments (ticket_id, message_id, user_id, filename, original_name, file_size, file_type)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$ticketId, $messageId, $user['id'], $filename, $originalName, $fileSize, $fileType]);
        $attachmentId = $db->lastInsertId();

        respond([
            'success'       => true,
            'attachment_id' => $attachmentId,
            'filename'      => $filename,
            'original_name' => $originalName,
            'file_size'     => $fileSize,
            'file_type'     => $fileType,
            'message'       => 'File uploaded successfully'
        ], 201);

    // GET /uploads.php?action=list&ticket_id=X
    case 'list':
        $user = requireAuth();
        $db   = getDB();

        $ticketId = (int)($_GET['ticket_id'] ?? 0);
        if (!$ticketId) respond(['error' => 'Ticket ID required'], 422);

        // Verify access
        $stmt = $db->prepare("SELECT * FROM tickets WHERE id = ?");
        $stmt->execute([$ticketId]);
        $ticket = $stmt->fetch();

        if (!$ticket) respond(['error' => 'Ticket not found'], 404);
        if ($user['role'] === 'user' && $ticket['user_id'] != $user['id']) {
            respond(['error' => 'Forbidden'], 403);
        }

        $stmt = $db->prepare("
            SELECT a.*, u.name AS uploader_name
            FROM attachments a
            JOIN users u ON a.user_id = u.id
            WHERE a.ticket_id = ?
            ORDER BY a.created_at DESC
        ");
        $stmt->execute([$ticketId]);
        $attachments = $stmt->fetchAll();

        respond(['success' => true, 'attachments' => $attachments]);

    // GET /uploads.php?action=download&id=X
    case 'download':
        $user = requireAuth();
        $db   = getDB();

        $id   = (int)($_GET['id'] ?? 0);
        $stmt = $db->prepare("
            SELECT a.*, t.user_id AS ticket_owner
            FROM attachments a
            JOIN tickets t ON a.ticket_id = t.id
            WHERE a.id = ?
        ");
        $stmt->execute([$id]);
        $attachment = $stmt->fetch();

        if (!$attachment) respond(['error' => 'File not found'], 404);

        if ($user['role'] === 'user' && $attachment['ticket_owner'] != $user['id']) {
            respond(['error' => 'Forbidden'], 403);
        }

        $filePath = __DIR__ . '/uploads/' . $attachment['filename'];
        if (!file_exists($filePath)) {
            respond(['error' => 'File not found on server'], 404);
        }

        // Stream file to browser
        header('Content-Type: ' . $attachment['file_type']);
        header('Content-Disposition: attachment; filename="' . $attachment['original_name'] . '"');
        header('Content-Length: ' . $attachment['file_size']);
        header('Cache-Control: no-cache');
        readfile($filePath);
        exit;

    // DELETE /uploads.php?action=delete&id=X
    case 'delete':
        $user = requireAuth();
        $db   = getDB();

        $id   = (int)($_GET['id'] ?? 0);
        $stmt = $db->prepare("SELECT * FROM attachments WHERE id = ?");
        $stmt->execute([$id]);
        $attachment = $stmt->fetch();

        if (!$attachment) respond(['error' => 'File not found'], 404);

        // Only uploader or admin can delete
        if ($user['role'] !== 'admin' && $attachment['user_id'] != $user['id']) {
            respond(['error' => 'Forbidden'], 403);
        }

        // Delete from disk
        $filePath = __DIR__ . '/uploads/' . $attachment['filename'];
        if (file_exists($filePath)) unlink($filePath);

        // Delete from database
        $db->prepare("DELETE FROM attachments WHERE id = ?")->execute([$id]);

        respond(['success' => true, 'message' => 'File deleted']);

    default:
        respond(['error' => 'Unknown action'], 404);
}