-- HELPDESK TICKET SYSTEM - DATABASE SETUP
CREATE DATABASE IF NOT EXISTS db_helpdesk CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_helpdesk;

-- USERS TABLE
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin', 'agent') DEFAULT 'user',
    avatar VARCHAR(10) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- CATEGORIES TABLE
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    color VARCHAR(7) DEFAULT '#6366f1',
    icon VARCHAR(50) DEFAULT '🔧'
);

-- TICKETS TABLE
CREATE TABLE IF NOT EXISTS tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_number VARCHAR(20) NOT NULL UNIQUE,
    subject VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    status ENUM('open', 'in_progress', 'closed') DEFAULT 'open',
    priority ENUM('low', 'medium', 'high') DEFAULT 'medium',
    category_id INT,
    user_id INT NOT NULL,
    assigned_to INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- MESSAGES TABLE
CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT NOT NULL,
    user_id INT NOT NULL,
    message TEXT NOT NULL,
    is_internal TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ATTACHMENTS TABLE
CREATE TABLE IF NOT EXISTS attachments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT NOT NULL,
    message_id INT DEFAULT NULL,
    user_id INT NOT NULL,
    filename VARCHAR(255) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    file_size INT NOT NULL,
    file_type VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);


-- INSERTING DATA
-- Default categories
INSERT INTO categories (name, color, icon) VALUES
('Technical Support', '#6366f1', '💻'),
('Billing', '#f59e0b', '💳'),
('Account', '#10b981', '👤'),
('Network', '#3b82f6', '🌐'),
('Hardware', '#ef4444', '🖥️'),
('Software', '#8b5cf6', '📦'),
('General Inquiry', '#6b7280', '❓');


-- USERS
INSERT INTO users (name, email, password, role, avatar) VALUES
('Admin User',      'admin@helpdesk.com',    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', '🛡️'),
('Support Agent',   'agent@helpdesk.com',    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'agent', '🎧'),
('Leila Riley',     'leila@example.com',     '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user',  '😊'),
('Erik Durham',     'erik@example.com',      '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user',  '🙂'),
('Martin Harris',   'martin@example.com',    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user',  '😎'),
('Leona Houston',   'leona@example.com',     '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user',  '👩'),
('Alice Jacobs',    'alice@example.com',     '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user',  '😄'),
('Charli Branch',   'charli@example.com',    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user',  '🤓'),
('Stella Andersen', 'stella@example.com',    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user',  '😊'),
('Jonah Lynn',      'jonah@example.com',     '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user',  '🙃'),
('Adelina Patrick', 'adelina@example.com',   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user',  '😇'),
('Elaine David',    'elaine@example.com',    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user',  '🧑');


-- TICKETS (20 tickets matching the data)
INSERT INTO tickets (ticket_number, subject, description, status, priority, category_id, user_id, assigned_to, created_at) VALUES
('TKT-100001', 'System is slow',        'The system has been running very slowly for the past day. Every action takes a long time to respond and pages load slowly.',                                        'open',        'high',     1, 3,    NULL, NOW() - INTERVAL 1 DAY),
('TKT-100002', 'Login issue',           'I am unable to log into my account. The page keeps refreshing and I never get past the login screen even with correct credentials.',                            'in_progress', 'medium',   3, 4,    2,    NOW() - INTERVAL 2 DAY),
('TKT-100003', 'Permission denied',     'I keep getting a Permission Denied error when trying to access certain folders and files that I should have access to.',                                        'closed',      'medium',   1, 5,    NULL, NOW() - INTERVAL 3 DAY),
('TKT-100004', 'WiFi issue',            'My device cannot connect to the office WiFi network. It shows connected but there is no internet access. Other devices on the same network work fine.',        'open',        'high',     4, 6,    2,    NOW() - INTERVAL 1 DAY),
('TKT-100005', 'Email not sending',     'Outgoing emails are stuck in the Outbox and never get delivered. The error message says connection to server failed but receiving emails works fine.',          'in_progress', 'high',     1, 7,    2,    NOW() - INTERVAL 4 DAY),
('TKT-100006', 'Account locked',        'My account has been locked after multiple failed login attempts. I need it unlocked so I can get back to work.',                                               'closed',      'low',      3, 8,    NULL, NOW() - INTERVAL 5 DAY),
('TKT-100007', 'File upload error',     'When I try to upload files to the shared drive I get an error saying the upload failed. This happens with all file types and sizes.',                          'open',        'medium',   6, 9,    2,    NOW() - INTERVAL 2 DAY),
('TKT-100008', 'System crash',          'My computer crashed suddenly this morning and restarted by itself. Since then it has happened two more times. I am losing unsaved work.',                      'open',        'high', 5, 10,   NULL, NOW() - INTERVAL 1 DAY),
('TKT-100009', 'Slow internet',         'The internet connection at my workstation is extremely slow. Websites take minutes to load and video calls are unusable.',                                     'in_progress', 'medium',   4, 11,   2,    NOW() - INTERVAL 2 DAY),
('TKT-100010', 'Cannot login',          'I cannot login to the system at all. I have tried resetting my password twice but the issue persists. Please help urgently.',                                  'closed',      'high',     3, 12,   NULL, NOW() - INTERVAL 2 DAY),
('TKT-100011', 'System is slow',        'Performance has degraded significantly. The dashboard takes over 30 seconds to load and reports time out before completing.',                                  'open',        'high',     1, 3,    2,    NOW() - INTERVAL 1 DAY),
('TKT-100012', 'Login issue',           'Getting a session expired error immediately after logging in. I am redirected back to the login page within seconds.',                                        'in_progress', 'medium',   3, 4,    2,    NOW() - INTERVAL 2 DAY),
('TKT-100013', 'Permission denied',     'Cannot access the admin panel despite having admin rights. The system shows Permission Denied on every admin page.',                                          'closed',      'medium',   1, 5,    NULL, NOW() - INTERVAL 3 DAY),
('TKT-100014', 'WiFi issue',            'WiFi drops every 10-15 minutes and reconnects automatically but it interrupts ongoing work. This has been happening since yesterday.',                        'open',        'medium',   4, 6,    2,    NOW() - INTERVAL 1 DAY),
('TKT-100015', 'Email not sending',     'Bulk email notifications are not being sent to customers. The email logs show errors but individual emails work fine.',                                       'in_progress', 'high', 1, 7,    2,    NOW() - INTERVAL 4 DAY),
('TKT-100016', 'Account locked',        'User account got locked due to a system error, not failed logins. The admin panel shows the account as active but login still fails.',                        'closed',      'low',      3, 8,    NULL, NOW() - INTERVAL 5 DAY),
('TKT-100017', 'File upload error',     'PDF files over 5MB fail to upload with a 413 error. Smaller files work fine. This is blocking urgent document submissions.',                                  'open',        'high',     6, 9,    2,    NOW() - INTERVAL 2 DAY),
('TKT-100018', 'System crash',          'The application crashes every time I try to generate a monthly report. It worked last week without issues.',                                                   'open',        'high', 5, 10,   NULL, NOW() - INTERVAL 1 DAY),
('TKT-100019', 'Slow internet',         'Since this morning the internet is very slow only on my machine. I ran a speed test and getting 0.5Mbps download when it should be 100Mbps.',                'in_progress', 'medium',   4, 11,   2,    NOW() - INTERVAL 2 DAY),
('TKT-100020', 'Cannot login',          'After the system update this morning none of my credentials work. I have tried both my regular account and backup account.',                                   'closed',      'high',     3, 12,   NULL, NOW() - INTERVAL 2 DAY);


-- MESSAGES (2-4 replies per ticket)
-- TKT-100001 (System is slow - Leila)
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(1, 2,  'Hi Leila, thank you for reaching out. We have received your ticket and will investigate the performance issue right away.', NOW() - INTERVAL 23 HOUR),
(1, 3,  'Thank you. It has been slow since yesterday morning. Even basic tasks like opening a file take forever.', NOW() - INTERVAL 22 HOUR),
(1, 2,  'We have identified a background process consuming high CPU on the server. Our team is working on a fix now.', NOW() - INTERVAL 20 HOUR);

-- TKT-100002 (Login issue - Erik)
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(2, 2,  'Hello Erik, I can see your account in our system. Can you tell me which browser you are using and if you have tried clearing the cache?', NOW() - INTERVAL 47 HOUR),
(2, 4,  'I am using Chrome. I tried clearing the cache but the problem persists.', NOW() - INTERVAL 46 HOUR),
(2, 2,  'I have reset your session tokens. Please try logging in again and let me know if the issue continues.', NOW() - INTERVAL 44 HOUR),
(2, 4,  'It worked! I can log in now. Thank you so much.', NOW() - INTERVAL 43 HOUR);

-- TKT-100003 (Permission denied - Martin) [CLOSED]
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(3, 2,  'Hi Martin, which specific folders are you unable to access? Please send me the exact file paths.', NOW() - INTERVAL 71 HOUR),
(3, 5,  'The path is /shared/reports/2024 and /shared/finance. I had access last week.', NOW() - INTERVAL 70 HOUR),
(3, 2,  'I found the issue — your access group was accidentally removed during a system update. I have restored your permissions.', NOW() - INTERVAL 68 HOUR),
(3, 5,  'I can access the folders now. Thank you for the quick fix!', NOW() - INTERVAL 67 HOUR);

-- TKT-100004 (WiFi issue - Leona)
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(4, 2,  'Hi Leona, please try forgetting the network and reconnecting. Also check if your network adapter drivers are up to date.', NOW() - INTERVAL 22 HOUR),
(4, 6,  'I tried that but it still shows no internet. My phone connects fine to the same WiFi though.', NOW() - INTERVAL 21 HOUR),
(4, 2,  'This looks like a device-specific issue. I will escalate to our on-site technician to check your workstation.', NOW() - INTERVAL 18 HOUR);

-- TKT-100005 (Email not sending - Alice)
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(5, 2,  'Hello Alice, can you check your SMTP settings? The outgoing server should be mail.company.com on port 587.', NOW() - INTERVAL 95 HOUR),
(5, 7,  'The settings look correct. Port is 587 and the server address matches what you said.', NOW() - INTERVAL 94 HOUR),
(5, 2,  'I can see the mail server had an authentication error in the logs. I have reset the mail service credentials on the server side.', NOW() - INTERVAL 90 HOUR),
(5, 7,  'Emails are going through now! Thank you for resolving this.', NOW() - INTERVAL 88 HOUR);

-- TKT-100006 (Account locked - Charli) [CLOSED]
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(6, 2,  'Hi Charli, I have unlocked your account. You should be able to log in now. Please update your password as well.', NOW() - INTERVAL 119 HOUR),
(6, 8,  'I can log in now. I updated my password too. Thank you!', NOW() - INTERVAL 118 HOUR);

-- TKT-100007 (File upload error - Stella)
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(7, 2,  'Hi Stella, what is the size of the files you are trying to upload? Also, are you uploading through the web interface or the desktop app?', NOW() - INTERVAL 47 HOUR),
(7, 9,  'I am using the web interface. The files are mostly documents, around 2-10MB each.', NOW() - INTERVAL 46 HOUR),
(7, 2,  'There seems to be a configuration issue with the upload limit. I have increased the max file size on the server. Please try again.', NOW() - INTERVAL 44 HOUR);

-- TKT-100008 (System crash - Jonah)
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(8, 2,  'Hi Jonah, this sounds serious. Can you check the Event Viewer logs and send us the error codes you see under Windows Logs > System?', NOW() - INTERVAL 23 HOUR),
(8, 10, 'I see errors mentioning KERNEL_SECURITY_CHECK_FAILURE and a blue screen code 0x00000139.', NOW() - INTERVAL 22 HOUR),
(8, 2,  'That error usually points to a driver issue or faulty RAM. I am escalating this to our hardware team. They will contact you shortly.', NOW() - INTERVAL 20 HOUR);

-- TKT-100009 (Slow internet - Adelina)
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(9, 2,  'Hello Adelina, please try connecting via ethernet cable instead of WiFi and run a speed test. Share the results with us.', NOW() - INTERVAL 47 HOUR),
(9, 11, 'Via ethernet I am getting 95Mbps. Via WiFi only 0.8Mbps. So it seems to be a WiFi issue.', NOW() - INTERVAL 46 HOUR),
(9, 2,  'Thank you for testing. The WiFi access point near your desk has a fault. We have scheduled a replacement for tomorrow.', NOW() - INTERVAL 44 HOUR),
(9, 11, 'Good to know. I will use ethernet in the meantime. Thanks for the update.', NOW() - INTERVAL 43 HOUR);

-- TKT-100010 (Cannot login - Elaine) [CLOSED]
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(10, 2,  'Hi Elaine, I can see your account was flagged by our security system. I have cleared the flag and reset your password. Check your email for the temporary password.', NOW() - INTERVAL 47 HOUR),
(10, 12, 'I received the email and logged in successfully. Thank you for the fast response!', NOW() - INTERVAL 46 HOUR);

-- TKT-100011 (System is slow again - Leila)
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(11, 2,  'Hi Leila, we see this is a recurring issue for you. We are going to run a full diagnostic on your account and connected services.', NOW() - INTERVAL 22 HOUR),
(11, 3,  'Yes it happens regularly. Dashboard reports are especially slow, sometimes timing out completely.', NOW() - INTERVAL 21 HOUR),
(11, 2,  'Diagnostic is running. We suspect a query optimization issue on the reports module. Our dev team is reviewing.', NOW() - INTERVAL 19 HOUR);

-- TKT-100012 (Login issue again - Erik)
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(12, 2,  'Hello Erik, the session expiry issue may be related to your browser security settings. Can you try disabling any VPN or extensions?', NOW() - INTERVAL 47 HOUR),
(12, 4,  'I disabled my VPN and the session lasts longer now but still expires after about 5 minutes.', NOW() - INTERVAL 46 HOUR),
(12, 2,  'I have extended the session timeout on your account to 60 minutes. Please test and confirm.', NOW() - INTERVAL 44 HOUR);

-- TKT-100013 (Permission denied - Martin) [CLOSED]
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(13, 2,  'Hi Martin, I can see your admin role is correctly set. There may be a cache issue. Please log out and back in.', NOW() - INTERVAL 71 HOUR),
(13, 5,  'Logging out and back in did not help. Same Permission Denied on all admin pages.', NOW() - INTERVAL 70 HOUR),
(13, 2,  'Found it — a middleware update broke admin role detection. I have applied a patch. You should have full access now.', NOW() - INTERVAL 68 HOUR),
(13, 5,  'Admin panel is working perfectly now. Thank you for the quick patch!', NOW() - INTERVAL 67 HOUR);

-- TKT-100014 (WiFi drops - Leona)
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(14, 2,  'Hi Leona, frequent WiFi drops can be caused by channel interference. Can you move closer to the access point and test?', NOW() - INTERVAL 22 HOUR),
(14, 6,  'I moved next to the router and still get drops. Other people in the office are fine though.', NOW() - INTERVAL 21 HOUR),
(14, 2,  'This confirms it is your network adapter. Please update your WiFi drivers. I am sending you a link to the latest drivers for your laptop model.', NOW() - INTERVAL 19 HOUR);

-- TKT-100015 (Bulk email issue - Alice)
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(15, 2,  'Hi Alice, bulk email failures are often caused by rate limiting. How many emails are being sent per hour?', NOW() - INTERVAL 95 HOUR),
(15, 7,  'The system sends about 2000 notification emails per hour during peak times.', NOW() - INTERVAL 94 HOUR),
(15, 2,  'That exceeds our current SMTP server limit. I am upgrading the mail queue configuration to support higher throughput.', NOW() - INTERVAL 90 HOUR);

-- TKT-100016 (Account locked by system - Charli) [CLOSED]
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(16, 2,  'Hi Charli, I see a system-triggered lockout on your account from a routine security scan. I have unlocked it and whitelisted your IP.', NOW() - INTERVAL 119 HOUR),
(16, 8,  'That explains it! I can log in again. Thanks for sorting it out so quickly.', NOW() - INTERVAL 118 HOUR);

-- TKT-100017 (PDF upload - Stella)
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(17, 2,  'Hi Stella, the 413 error means the file exceeds the server upload limit. What is the exact size of the PDFs you are trying to upload?', NOW() - INTERVAL 47 HOUR),
(17, 9,  'The PDFs are around 8-12MB each. I need to upload quarterly reports urgently.', NOW() - INTERVAL 46 HOUR),
(17, 2,  'I have raised the upload limit to 50MB on the server. Please try uploading again and let me know if it works.', NOW() - INTERVAL 44 HOUR),
(17, 9,  'The upload went through! All 3 reports are uploaded now. Thank you!', NOW() - INTERVAL 43 HOUR);

-- TKT-100018 (Report crash - Jonah)
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(18, 2,  'Hi Jonah, does the crash happen with all reports or just the monthly one? Also, what date range are you selecting?', NOW() - INTERVAL 22 HOUR),
(18, 10, 'Only the monthly report crashes. The date range is the full month of November 2024.', NOW() - INTERVAL 21 HOUR),
(18, 2,  'I reproduced the issue on our test server. There is a bug with datasets over 50,000 rows in the report generator. Our dev team is on it.', NOW() - INTERVAL 19 HOUR);

-- TKT-100019 (Slow internet - Adelina second ticket)
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(19, 2,  'Hello Adelina, since this started after this morning I suspect it may be related to the network maintenance we did overnight. Can you restart your network adapter?', NOW() - INTERVAL 47 HOUR),
(19, 11, 'I restarted the adapter and also rebooted my PC. Speed is still 0.5Mbps.', NOW() - INTERVAL 46 HOUR),
(19, 2,  'I can see your workstation port on the switch was set to 10Mbps instead of auto-negotiate after the maintenance. I have fixed the switch config.', NOW() - INTERVAL 44 HOUR),
(19, 11, 'Speed test now shows 99Mbps! That fixed it completely. Thank you!', NOW() - INTERVAL 43 HOUR);

-- TKT-100020 (Post-update login - Elaine) [CLOSED]
INSERT INTO messages (ticket_id, user_id, message, created_at) VALUES
(20, 2,  'Hi Elaine, the system update this morning included a password policy change. All users need to reset their passwords on first login after the update.', NOW() - INTERVAL 47 HOUR),
(20, 12, 'I was not aware of that. Where do I go to reset my password?', NOW() - INTERVAL 46 HOUR),
(20, 2,  'Go to the login page and click Forgot Password. Enter your email and you will receive a reset link. The link expires in 30 minutes.', NOW() - INTERVAL 45 HOUR),
(20, 12, 'Done! I reset my password and can log in now. Maybe send a notice before updates next time?', NOW() - INTERVAL 44 HOUR),
(20, 1,  'That is a fair point, Elaine. We will make sure to send advance notices for updates that affect login. Closing this ticket as resolved.', NOW() - INTERVAL 43 HOUR);