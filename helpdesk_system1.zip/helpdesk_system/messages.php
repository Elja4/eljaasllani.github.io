<?php
// MESSAGES API
require_once __DIR__ . '/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$body   = json_decode(file_get_contents('php://input'), true) ?? [];

switch ($action) {

    // POST /messages.php?action=add
    case 'add':
        if ($method !== 'POST') respond(['error' => 'Method not allowed'], 405);
        $user = requireAuth();
        $db   = getDB();

        $ticketId   = (int)($body['ticket_id'] ?? 0);
        $message  = trim($body['message'] ?? '');
        $isInternal = (int)($body['is_internal'] ?? 0);

        if (!$ticketId || !$message) {
            respond(['error' => 'Ticket ID and message are required'], 422);
        }

        // Verify ticket exists and user has access
        $stmt = $db->prepare("SELECT * FROM tickets WHERE id = ?");
        $stmt->execute([$ticketId]);
        $ticket = $stmt->fetch();

        if (!$ticket) respond(['error' => 'Ticket not found'], 404);

        if ($user['role'] === 'user' && $ticket['user_id'] != $user['id']) {
            respond(['error' => 'Forbidden'], 403);
        }

        // Regular users can't post internal notes
        if ($user['role'] === 'user') $isInternal = 0;

        $stmt = $db->prepare(
            "INSERT INTO messages (ticket_id, user_id, message, is_internal) VALUES (?, ?, ?, ?)"
        );
        $stmt->execute([$ticketId, $user['id'], $message, $isInternal]);
        $messageId = $db->lastInsertId();

        // Send notification email
        require_once __DIR__ . '/mailer.php';

        $stmt = $db->prepare("
            SELECT u.name, u.email, t.subject, t.ticket_number
            FROM tickets t
            JOIN users u ON t.user_id = u.id
            WHERE t.id = ?
        ");
        $stmt->execute([$ticketId]);
        $ticketInfo = $stmt->fetch();

        // Don't email the person who just replied
        if ($ticketInfo && $ticketInfo['email'] !== $user['email']) {
            sendMail(
                $ticketInfo['email'],
                $ticketInfo['name'],
                "New Reply - {$ticketInfo['ticket_number']}",
                "There is a new reply on your ticket.<br><br>
                <strong>Ticket:</strong> {$ticketInfo['ticket_number']}<br>
                <strong>Subject:</strong> {$ticketInfo['subject']}<br><br>
                <strong>Message:</strong><br>{$message}<br><br>
                Login to DeskFlow to view and respond."
            );
        }
        // Auto-update ticket status to in_progress if it was open
        if ($ticket['status'] === 'open' && in_array($user['role'], ['admin', 'agent'])) {
            $db->prepare("UPDATE tickets SET status = 'in_progress' WHERE id = ?")->execute([$ticketId]);
        }

        respond([
            'success'  => true,
            'message_id' => $messageId,
            'message'  => 'Reply added'
        ], 201);

    // DELETE /messages.php?action=delete&id=X
    case 'delete':
        $user = requireRole(['admin']);
        $db   = getDB();
        $id   = (int)($_GET['id'] ?? 0);

        $stmt = $db->prepare("DELETE FROM messages WHERE id = ?");
        $stmt->execute([$id]);

        respond(['success' => true, 'message' => 'Message deleted']);

    default:
        respond(['error' => 'Unknown action'], 404);
}