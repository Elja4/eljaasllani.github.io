// MAIN APP JAVASCRIPT
let currentUser = null;
let allTickets   = [];

// API 
async function api(endpoint, options = {}) {
   const res = await fetch(endpoint, {
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
        ...options,
        body: options.body ? JSON.stringify(options.body) : undefined,
    });
    const data = await res.json();
    if (!res.ok && data.error) throw new Error(data.error);
    return data;
}

// AUTH
async function authLogin() {
    const email    = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    const errEl    = document.getElementById('login-error');
    errEl.classList.add('hidden');

    if (!email || !password) { showError(errEl, 'Please fill in all fields'); return; }

    try {
        const res = await api('auth.php?action=login', { method: 'POST', body: { email, password } });
        currentUser = res.user;
        startApp();
    } catch (e) {
        showError(errEl, e.message);
    }
}

async function authRegister() {
    const name     = document.getElementById('reg-name').value.trim();
    const email    = document.getElementById('reg-email').value.trim();
    const password = document.getElementById('reg-password').value;
    const role     = document.getElementById('reg-role').value;
    const errEl    = document.getElementById('reg-error');
    errEl.classList.add('hidden');

    if (!name || !email || !password) { showError(errEl, 'All fields are required'); return; }

    try {
        const res = await api('auth.php?action=register', { method: 'POST', body: { name, email, password, role } });
        currentUser = res.user;
        startApp();
    } catch (e) {
        showError(errEl, e.message);
    }
}

async function authLogout() {
    await api('auth.php?action=logout', { method: 'POST' });
    currentUser = null;
    document.getElementById('app').classList.add('hidden');
    document.getElementById('auth-screen').classList.remove('hidden');
}


// APP INIT
window.addEventListener('DOMContentLoaded', async () => {
    // Auth tab switching
    document.querySelectorAll('.auth-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
            tab.classList.add('active');
            document.getElementById(tab.dataset.tab + '-form').classList.add('active');
        });
    });

    // Enter key for login
    document.getElementById('login-password').addEventListener('keydown', e => {
        if (e.key === 'Enter') authLogin();
    });

    // Check if already logged in
    try {
        const res = await api('auth.php?action=me');
        if (res.authenticated) {
            currentUser = res.user;
            startApp();
        }
    } catch (e) { /* not logged in */ }
});

function startApp() {
    document.getElementById('auth-screen').classList.add('hidden');
    document.getElementById('app').classList.remove('hidden');
    setupUserUI();
    loadCategories();

    // Land on right page based on role
    if (currentUser.role === 'user') {
        navigate('tickets');
    } else {
        navigate('dashboard');
    }
}

function setupUserUI() {
    document.getElementById('sidebar-avatar').textContent = currentUser.avatar || '😊';
    document.getElementById('sidebar-name').textContent   = currentUser.name;
    document.getElementById('sidebar-role').textContent   = currentUser.role;

    const isStaff = ['admin', 'agent'].includes(currentUser.role);
    const isUser  = currentUser.role === 'user';

    // Show admin-only nav items for staff
    document.querySelectorAll('.admin-only').forEach(el => {
        if (isStaff) el.classList.remove('hidden');
        else el.classList.add('hidden');
    });

    // Hide "New Ticket" nav item and button for staff
    document.querySelectorAll('.user-only').forEach(el => {
        if (isUser) el.classList.remove('hidden');
        else el.classList.add('hidden');
    });
}


// NAVIGATION
function navigate(page) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

    const pageEl = document.getElementById('page-' + page);
    if (!pageEl) return;
    pageEl.classList.add('active');

    const navEl = document.querySelector(`[data-page="${page}"]`);
    if (navEl) navEl.classList.add('active');

    const titles = {
        'dashboard': 'Dashboard',
        'tickets':   'All Tickets',
        'new-ticket':'New Ticket',
        'users':     'Users',
        'categories':'Categories',
        'profile':   'My Profile',
        'ticket-detail': 'Ticket Details',
    };
    document.getElementById('page-title').textContent = titles[page] || page;

    // Close sidebar on mobile
    document.getElementById('sidebar').classList.remove('open');

    // Load page data
    if (page === 'dashboard')   loadDashboard();
    if (page === 'tickets')     loadTickets();
    if (page === 'users')       loadUsers();
    if (page === 'categories')  loadCategoriesPage();
    if (page === 'profile')     loadProfile();
}

function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
}


// DASHBOARD
async function loadDashboard() {
    if (['admin', 'agent'].includes(currentUser.role)) {
        try {
            const res = await api('tickets.php?action=stats');
            const s   = res.stats;

            document.getElementById('stat-total').textContent   = s.total || 0;
            document.getElementById('stat-closed').textContent  = s.by_status?.closed || 0;
            document.getElementById('stat-open').textContent    = s.by_status?.open || 0;
            document.getElementById('stat-today').textContent = s.today || 0;

            const badge = document.getElementById('open-badge');
            const openCount = s.by_status?.open || 0;
            badge.textContent = openCount || '';
            badge.style.display = openCount > 0 ? 'block' : 'none';

            renderBarChart('priority-chart', s.by_priority || {}, {
                high: '#ed0d0d', medium: '#f59e0b', low: '#22c55e'
            });
            renderBarChart('status-chart', s.by_status || {}, {
                open: '#3b82f6', in_progress: '#f59e0b', closed: '#6b7280'
            });

            // Weekly bar chart
            renderWeekChart(s.weekly || []);

        } catch(e) {}
    }

    try {
        const res = await api('tickets.php?action=list');
        allTickets = res.tickets;
        const recent = res.tickets.slice(0, 5);
        const el = document.getElementById('recent-tickets-list');
        el.innerHTML = recent.length
            ? recent.map(renderTicketCard).join('')
            : emptyState('No tickets yet', 'Submit a ticket to get started');
    } catch(e) {}
}

function renderWeekChart(weekData) {
    const chart = document.getElementById('dash-chart');
    if (!chart) return;

    // If no real data, use sample
    const days = weekData.length ? weekData : [
        {day:'Mon', total:0, closed:0, waiting:0},
        {day:'Tue', total:0, closed:0, waiting:0},
        {day:'Wed', total:0, closed:0, waiting:0},
        {day:'Thu', total:0, closed:0, waiting:0},
        {day:'Fri', total:0, closed:0, waiting:0},
        {day:'Sat', total:0, closed:0, waiting:0},
        {day:'Sun', total:0, closed:0, waiting:0},
    ];

    const maxVal = Math.max(...days.map(d => d.total), 1);
    const scale  = 160 / maxVal;

    chart.innerHTML = days.map(item => `
        <div class="dash-day">
            <div class="dash-bars">
                <div class="dash-bar closed"  style="height:${Math.max(item.closed  * scale, 4)}px"></div>
                <div class="dash-bar waiting" style="height:${Math.max(item.waiting * scale, 4)}px"></div>
                <div class="dash-bar total"   style="height:${Math.max(item.total   * scale, 4)}px"></div>
            </div>
            <span>${item.day}</span>
        </div>
    `).join('');
}
function renderBarChart(containerId, data, colors) {
    const el  = document.getElementById(containerId);
    if (!el) return;
    const max = Math.max(...Object.values(data).map(Number), 1);
    el.innerHTML = Object.entries(data).map(([key, val]) => `
        <div class="chart-bar-row">
            <div class="chart-label">${key.replace('_',' ')}</div>
            <div class="chart-bar-bg">
                <div class="chart-bar" style="width:${(val/max*100).toFixed(1)}%;background:${colors[key]||'#6366f1'}"></div>
            </div>
            <div class="chart-count">${val}</div>
        </div>
    `).join('') || '<div class="loading" style="padding:10px">No data</div>';
}


// TICKETS
async function loadTickets() {
    const el = document.getElementById('tickets-list');
    el.innerHTML = loadingHTML();
    try {
        const res  = await api('tickets.php?action=list');
        allTickets = res.tickets;
        renderTicketList(allTickets);
    } catch(e) {
        el.innerHTML = errorHTML(e.message);
    }
}

function renderTicketList(tickets) {
    const el = document.getElementById('tickets-list');
    el.innerHTML = tickets.length
        ? tickets.map(renderTicketCard).join('')
        : emptyState('No tickets found', 'Try adjusting your filters or submit a new ticket');
}

function renderTicketCard(t) {
    const cat = t.category_name
        ? `<span class="cat-badge">${t.category_icon||''}  ${t.category_name}</span>`
        : '';
    return `
        <div class="ticket-card" onclick="openTicket(${t.id})">
            <div class="ticket-left">
                <div class="ticket-meta">
                    <span class="ticket-number">${t.ticket_number}</span>
                    <span class="badge badge-${t.status}">${t.status.replace('_',' ')}</span>
                    <span class="badge badge-${t.priority}">${t.priority}</span>
                    ${cat}
                </div>
                <div class="ticket-subject">${escHtml(t.subject)}</div>
                <div class="ticket-info">
                    <span>By ${escHtml(t.user_name)}</span>
                    <span>${timeAgo(t.created_at)}</span>
                    ${t.assigned_name ? `<span>→ ${escHtml(t.assigned_name)}</span>` : ''}
                </div>
            </div>
            <div class="ticket-right">
                <span class="reply-count">💬 ${t.messages_count||0}</span>
            </div>
        </div>
    `;
}

function filterTickets() {
    const search   = document.getElementById('ticket-search').value.toLowerCase();
    const status   = document.getElementById('filter-status').value;
    const priority = document.getElementById('filter-priority').value;

    let filtered = allTickets;
    if (search)   filtered = filtered.filter(t => t.subject.toLowerCase().includes(search) || t.ticket_number.toLowerCase().includes(search));
    if (status)   filtered = filtered.filter(t => t.status === status);
    if (priority) filtered = filtered.filter(t => t.priority === priority);

    renderTicketList(filtered);
}


// TICKET DETAIL
async function openTicket(id) {
    navigate('ticket-detail');
    const el = document.getElementById('ticket-detail-content');
    el.innerHTML = loadingHTML();

    try {
        const res = await api(`tickets.php?action=get&id=${id}`);
        const t   = res.ticket;
        const r   = res.messages;
        const isStaff = ['admin','agent'].includes(currentUser.role);

        const agentsHtml = isStaff ? await loadAgentSelectForTicket(t.assigned_to) : '';
        const statusSelect = isStaff ? `
            <select onchange="updateTicket(${t.id}, 'status', this.value)">
                ${['open','in_progress','closed'].map(s =>
                    `<option value="${s}" ${t.status===s?'selected':''}>${s.replace('_',' ')}</option>`
                ).join('')}
            </select>
        ` : `<span class="badge badge-${t.status}">${t.status.replace('_',' ')}</span>`;

        const prioritySelect = isStaff ? `
            <select onchange="updateTicket(${t.id}, 'priority', this.value)">
                ${['low','medium','high'].map(p =>
                    `<option value="${p}" ${t.priority===p?'selected':''}>${p}</option>`
                ).join('')}
            </select>
        ` : `<span class="badge badge-${t.priority}">${t.priority}</span>`;

        el.innerHTML = `
            <div class="detail-grid">
                <div class="detail-main">
                    <div class="detail-card">
                        <div class="detail-meta">
                            <span class="ticket-number">${t.ticket_number}</span>
                            <span class="badge badge-${t.status}">${t.status.replace('_',' ')}</span>
                            <span class="badge badge-${t.priority}">${t.priority}</span>
                        </div>
                        <div class="detail-subject">${escHtml(t.subject)}</div>
                        <div class="detail-body">${escHtml(t.description)}</div>
                    </div>

                    <div class="detail-card">
                        <div class="detail-label">Conversation (${r.length} replies)</div>
                        <div id="replies-container">
                            ${r.length ? r.map(renderReply).join('') : `<div style="color:var(--text3);font-size:.85rem;padding:10px 0">No replies yet.</div>`}
                        </div>
                        <div class="detail-divider"></div>
                       <div class="reply-box">
                      
                   <div class="detail-divider"></div>
                       <div class="detail-label">Attachments</div>
                       <div id="attachments-list" class="attachments-list">
                       <div class="loading"><div class="spinner"></div> Loading...</div>
                       </div>
                       <textarea id="reply-input" rows="4" placeholder="Write your message..."></textarea>
                       
                       <div class="attach-area" id="attach-area">
                         <label class="attach-btn" for="file-input">📎 Attach File</label>
                         <input type="file" id="file-input" style="display:none" onchange="previewFile(this)">
                         <span id="file-preview" class="file-preview"></span>
                       </div>
            
                       <div class="reply-box-actions">
                       <div class="reply-options">
                          ${isStaff ? `
                       <label class="internal-check">
                          <input type="checkbox" id="reply-internal"> Internal note
                       </label>` : ''}
                       </div>
                         <button class="btn-sm" onclick="submitReply(${t.id})">Send Message</button>
                       </div>
                    </div>
                </div>
            </div>

                <div class="detail-sidebar">
                    <div class="info-card">
                        <div class="info-card-title">Ticket Info</div>
                        <div class="info-row">
                            <div class="info-row-label">Submitted by</div>
                            <div class="info-row-value">${escHtml(t.user_name)}<br><small style="color:var(--text3)">${escHtml(t.user_email)}</small></div>
                        </div>
                        <div class="info-row">
                            <div class="info-row-label">Created</div>
                            <div class="info-row-value">${formatDate(t.created_at)}</div>
                        </div>
                        <div class="info-row">
                            <div class="info-row-label">Category</div>
                            <div class="info-row-value">${t.category_name ? `${t.category_icon} ${t.category_name}` : '—'}</div>
                        </div>
                        
                    </div>

                    ${isStaff ? `
                    <div class="info-card admin-controls">
                        <div class="info-card-title">Management</div>
                        <div class="info-row-label" style="margin-bottom:6px">Status</div>
                        ${statusSelect}
                        <div class="info-row-label" style="margin-bottom:6px;margin-top:10px">Priority</div>
                        ${prioritySelect}
                        <div class="info-row-label" style="margin-bottom:6px;margin-top:10px">Assigned To</div>
                        ${agentsHtml}
                    </div>` : ''}
                </div>
            </div>
        `;
    } catch(e) {
        el.innerHTML = errorHTML(e.message);
       
loadAttachments(t.id);
    }
}

function renderReply(r) {
    return `
        <div class="reply-item ${r.is_internal ? 'internal' : ''}">
            <div class="reply-avatar">${r.author_avatar || '😊'}</div>
            <div class="reply-content">
                <div class="reply-author">
                    ${escHtml(r.author_name)}
                    ${r.author_role !== 'user' ? `<span class="reply-role-badge">${r.author_role}</span>` : ''}
                    ${r.is_internal ? `<span class="internal-badge">internal</span>` : ''}
                    <span class="reply-time">${timeAgo(r.created_at)}</span>
                </div>
                <div class="reply-message">${escHtml(r.message)}</div>
            </div>
        </div>
    `;
}

async function submitReply(ticketId) {
    const message    = document.getElementById('reply-input').value.trim();
    const isInternal = document.getElementById('reply-internal')?.checked ? 1 : 0;

    if (!message) { showToast('Please write a message', 'error'); return; }

    try {
        const res = await api('messages.php?action=add', {
            method: 'POST',
            body: { ticket_id: ticketId, message, is_internal: isInternal }
        });

        // Upload file if one is selected
        const fileInput = document.getElementById('file-input');
        if (fileInput && fileInput.files[0]) {
            await uploadFile(ticketId, res.message_id);
        }

        showToast('Message sent!', 'success');
        openTicket(ticketId);
    } catch(e) {
        showToast(e.message, 'error');
    }
}

async function updateTicket(id, field, value) {
    try {
        await api(`tickets.php?action=update&id=${id}`, {
            method: 'POST',
            body: { [field]: value }
        });
        showToast('Updated!', 'success');
    } catch(e) {
        showToast(e.message, 'error');
    }
}

async function loadAgentSelectForTicket(ticketId, currentAssigned) {
    try {
        const res = await api('users.php?action=agents');
        const options = `<option value="">Unassigned</option>` +
            res.agents.map(a => `<option value="${a.id}" ${a.id == currentAssigned ? 'selected' : ''}>${a.name}</option>`).join('');
        return `<select data-ticket="${ticketId}" onchange="updateTicket(${ticketId}, 'assigned_to', this.value)">${options}</select>`;
    } catch(e) { return '—'; }
}

// NEW TICKET
async function submitTicket() {
    const subject     = document.getElementById('nt-subject').value.trim();
    const description = document.getElementById('nt-description').value.trim();
    const priority    = document.getElementById('nt-priority').value;
    const categoryId  = document.getElementById('nt-category').value;
    const errEl       = document.getElementById('nt-error');
    errEl.classList.add('hidden');

    if (!subject || !description) {
        showError(errEl, 'Subject and description are required');
        return;
    }

    try {
        const res = await api('tickets.php?action=create', {
            method: 'POST',
            body: { subject, description, priority, category_id: categoryId || null }
        });
        showToast(`Ticket ${res.ticket_number} submitted!`, 'success');
        document.getElementById('nt-subject').value      = '';
        document.getElementById('nt-description').value  = '';
        navigate('tickets');
    } catch(e) {
        showError(errEl, e.message);
    }
}


// CATEGORIES
let categories = [];

async function loadCategories() {
    try {
        const res = await api('categories.php?action=list');
        categories = res.categories;
        const sel  = document.getElementById('nt-category');
        sel.innerHTML = '<option value="">Select category...</option>' +
            categories.map(c => `<option value="${c.id}">${c.icon} ${c.name}</option>`).join('');
    } catch(e) {}
}

async function loadCategoriesPage() {
    await loadCategories();
    const el = document.getElementById('categories-list');
    el.innerHTML = `
        <div class="form-card">
            <h2 class="form-card-title">All Categories</h2>
            <table class="data-table">
                <thead><tr><th>Icon</th><th>Name</th><th>Action</th></tr></thead>
                <tbody>
                    ${categories.map(c => `
                        <tr>
                            <td>${c.icon}</td>
                            <td>${escHtml(c.name)}</td>
                            <td><button class="btn-danger" onclick="deleteCategory(${c.id})">Delete</button></td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

async function createCategory() {
    const name = document.getElementById('cat-name').value.trim();
    const icon = document.getElementById('cat-icon').value.trim() || '🔧';
    if (!name) { showToast('Name is required', 'error'); return; }
    try {
        await api('categories.php?action=create', { method: 'POST', body: { name, icon } });
        showToast('Category created', 'success');
        document.getElementById('cat-name').value = '';
        document.getElementById('cat-icon').value = '';
        loadCategoriesPage();
    } catch(e) { showToast(e.message, 'error'); }
}

async function deleteCategory(id) {
    if (!confirm('Delete this category?')) return;
    try {
        await api(`categories.php?action=delete&id=${id}`, { method: 'DELETE' });
        showToast('Deleted', 'success');
        loadCategoriesPage();
    } catch(e) { showToast(e.message, 'error'); }
}

// USERS
async function loadUsers() {
    const el = document.getElementById('users-list');
    el.innerHTML = loadingHTML();
    try {
        const res = await api('users.php?action=list');
        el.innerHTML = `
            <div class="form-card">
                <h2 class="form-card-title">All Users (${res.users.length})</h2>
                <table class="data-table">
                    <thead><tr><th>User</th><th>Email</th><th>Role</th><th>Tickets</th><th>Joined</th><th>Action</th></tr></thead>
                    <tbody>
                        ${res.users.map(u => `
                            <tr>
                                <td><strong>${escHtml(u.name)}</strong></td>
                                <td>${escHtml(u.email)}</td>
                                <td>
                                    <select onchange="updateUserRole(${u.id}, this.value)" ${u.id == currentUser.id ? 'disabled' : ''}>
                                        <option value="user"  ${u.role==='user'  ?'selected':''}>User</option>
                                        <option value="agent" ${u.role==='agent' ?'selected':''}>Agent</option>
                                        <option value="admin" ${u.role==='admin' ?'selected':''}>Admin</option>
                                    </select>
                                </td>
                                <td>${u.ticket_count}</td>
                                <td>${formatDate(u.created_at, true)}</td>
                                <td>${u.id != currentUser.id
                                    ? `<button class="btn-danger" onclick="deleteUser(${u.id})">Delete</button>`
                                    : '<span style="color:var(--text3);font-size:.78rem">You</span>'
                                }</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    } catch(e) { el.innerHTML = errorHTML(e.message); }
}

async function updateUserRole(id, role) {
    try {
        await api(`users.php?action=update_role&id=${id}`, { method: 'POST', body: { role } });
        showToast('Role updated', 'success');
    } catch(e) { showToast(e.message, 'error'); }
}

async function deleteUser(id) {
    if (!confirm('Delete this user? This will also delete all their tickets.')) return;
    try {
        await api(`users.php?action=delete&id=${id}`, { method: 'DELETE' });
        showToast('User deleted', 'success');
        loadUsers();
    } catch(e) { showToast(e.message, 'error'); }
}


// PROFILE
function loadProfile() {
    document.getElementById('prof-name').value  = currentUser.name;
    document.getElementById('prof-email').value = currentUser.email;
}

async function saveProfile() {
    const name     = document.getElementById('prof-name').value.trim();
    const email    = document.getElementById('prof-email').value.trim();
    const password = document.getElementById('prof-password').value;
    const msgEl    = document.getElementById('prof-msg');
    msgEl.classList.add('hidden');

    try {
        await api('users.php?action=profile', { method: 'POST', body: { name, email, password: password || undefined } });
        currentUser.name  = name;
        currentUser.email = email;
        setupUserUI();
        msgEl.className  = 'form-success';
        msgEl.textContent = 'Profile updated successfully!';
        msgEl.classList.remove('hidden');
        setTimeout(() => msgEl.classList.add('hidden'), 3000);
    } catch(e) {
        showError(msgEl, e.message);
    }
}

// MODAL
function openModal(title, html) {
    document.getElementById('modal-title').textContent = title;
    document.getElementById('modal-body').innerHTML    = html;
    document.getElementById('modal-overlay').classList.remove('hidden');
}
function closeModal() {
    document.getElementById('modal-overlay').classList.add('hidden');
}


// HELPERS
function showToast(msg, type = 'success') {
    const el = document.getElementById('toast');
    el.textContent = msg;
    el.className   = `toast ${type}`;
    el.classList.remove('hidden');
    setTimeout(() => el.classList.add('hidden'), 3000);
}

function showError(el, msg) {
    el.textContent = msg;
    el.className   = 'form-error';
    el.classList.remove('hidden');
}

function escHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g,'&amp;')
        .replace(/</g,'&lt;')
        .replace(/>/g,'&gt;')
        .replace(/"/g,'&quot;');
}

function timeAgo(dateStr) {
    const diff = (Date.now() - new Date(dateStr)) / 1000;
    if (diff < 60)     return 'just now';
    if (diff < 3600)   return Math.floor(diff/60) + 'm ago';
    if (diff < 86400)  return Math.floor(diff/3600) + 'h ago';
    if (diff < 604800) return Math.floor(diff/86400) + 'd ago';
    return formatDate(dateStr, true);
}

function formatDate(dateStr, short = false) {
    if (!dateStr) return '—';
    const d = new Date(dateStr);
    if (short) return d.toLocaleDateString();
    return d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
}

function loadingHTML() {
    return `<div class="loading"><div class="spinner"></div> Loading...</div>`;
}

function errorHTML(msg) {
    return `<div class="empty-state"><div class="empty-icon">⚠️</div><h3>Error</h3><p>${escHtml(msg)}</p></div>`;
}

function emptyState(title, subtitle) {
    return `<div class="empty-state"><div class="empty-icon">🎫</div><h3>${title}</h3><p>${subtitle}</p></div>`;
}

// FILE UPLOAD
function previewFile(input) {
    const preview = document.getElementById('file-preview');
    if (input.files && input.files[0]) {
        const file = input.files[0];
        const size = (file.size / 1024).toFixed(1);
        preview.innerHTML = `📄 ${escHtml(file.name)} <span style="color:var(--text3)">(${size} KB)</span> <button onclick="clearFile()" style="background:none;border:none;color:var(--red);cursor:pointer;margin-left:6px">✕</button>`;
    }
}

function clearFile() {
    document.getElementById('file-input').value = '';
    document.getElementById('file-preview').innerHTML = '';
}

async function uploadFile(ticketId, messageId) {
    const fileInput = document.getElementById('file-input');
    if (!fileInput || !fileInput.files[0]) return null;

    const formData = new FormData();
    formData.append('file', fileInput.files[0]);
    formData.append('ticket_id', ticketId);
    if (messageId) formData.append('message_id', messageId);

    const res = await fetch('uploads.php?action=upload', {
        method: 'POST',
        credentials: 'include',
        body: formData
    });
    return await res.json();
}

async function loadAttachments(ticketId) {
    try {
        const res = await api(`uploads.php?action=list&ticket_id=${ticketId}`);
        const el  = document.getElementById('attachments-list');
        if (!el) return;

        if (!res.attachments.length) {
            el.innerHTML = '<div style="color:var(--text3);font-size:.82rem">No attachments yet.</div>';
            return;
        }

        el.innerHTML = res.attachments.map(a => {
            const size = (a.file_size / 1024).toFixed(1);
            const icon = a.file_type.startsWith('image') ? '🖼️' :
                         a.file_type === 'application/pdf' ? '📕' : '📄';
            return `
                <div class="attachment-item">
                    <span class="attach-icon">${icon}</span>
                    <div class="attach-info">
                        <div class="attach-name">${escHtml(a.original_name)}</div>
                        <div class="attach-meta">${size} KB · ${timeAgo(a.created_at)} · ${escHtml(a.uploader_name)}</div>
                    </div>
                    <a href="uploads.php?action=download&id=${a.id}" class="btn-sm" download>⬇ Download</a>
                    ${currentUser.role === 'admin' || a.user_id == currentUser.id ?
                        `<button class="btn-danger" onclick="deleteAttachment(${a.id}, ${ticketId})">✕</button>` : ''
                    }
                </div>
            `;
        }).join('');
    } catch(e) {}
}

async function deleteAttachment(id, ticketId) {
    if (!confirm('Delete this file?')) return;
    try {
        await api(`uploads.php?action=delete&id=${id}`);
        showToast('File deleted', 'success');
        loadAttachments(ticketId);
    } catch(e) {
        showToast(e.message, 'error');
    }
}