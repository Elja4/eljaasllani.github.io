<?php
// TICKETS API
require_once __DIR__ . '/db.php';
 
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$id     = (int)($_GET['id'] ?? 0);
$body   = json_decode(file_get_contents('php://input'), true) ?? [];
 
switch ($action) {
 
    // GET /tickets.php?action=list
    // Returns all tickets (admin/agent sees all, user sees own)
    case 'list':
        $user = requireAuth();
        $db   = getDB();
 
        $where  = '';
        $params = [];
 
        if ($user['role'] === 'user') {
            $where  = 'WHERE t.user_id = ?';
            $params = [$user['id']];
        }
 
        // Optional filters
        if (!empty($_GET['status'])) {
            $where   .= ($where ? ' AND ' : 'WHERE ') . 't.status = ?';
            $params[] = $_GET['status'];
        }
        if (!empty($_GET['priority'])) {
            $where   .= ($where ? ' AND ' : 'WHERE ') . 't.priority = ?';
            $params[] = $_GET['priority'];
        }
        if (!empty($_GET['search'])) {
            $where   .= ($where ? ' AND ' : 'WHERE ') . '(t.subject LIKE ? OR t.ticket_number LIKE ?)';
            $params[] = '%' . $_GET['search'] . '%';
            $params[] = '%' . $_GET['search'] . '%';
        }
 
        $sql = "
            SELECT
                t.*,
                u.name  AS user_name,
                u.email AS user_email,
                a.name  AS assigned_name,
                c.name  AS category_name,
                c.color AS category_color,
                c.icon  AS category_icon,
                (SELECT COUNT(*) FROM messages m WHERE m.ticket_id = t.id) AS messages_count
            FROM tickets t
            JOIN users u ON t.user_id = u.id
            LEFT JOIN users a ON t.assigned_to = a.id
            LEFT JOIN categories c ON t.category_id = c.id
            $where
            ORDER BY t.created_at DESC
        ";
 
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $tickets = $stmt->fetchAll();
 
        respond(['success' => true, 'tickets' => $tickets]);
 
    // GET /tickets.php?action=get&id=X
    case 'get':
        $user = requireAuth();
        $db   = getDB();
 
        $sql = "
            SELECT
                t.*,
                u.name  AS user_name,
                u.email AS user_email,
                u.avatar AS user_avatar,
                a.name  AS assigned_name,
                c.name  AS category_name,
                c.color AS category_color,
                c.icon  AS category_icon
            FROM tickets t
            JOIN users u ON t.user_id = u.id
            LEFT JOIN users a ON t.assigned_to = a.id
            LEFT JOIN categories c ON t.category_id = c.id
            WHERE t.id = ?
        ";
 
        $stmt = $db->prepare($sql);
        $stmt->execute([$id]);
        $ticket = $stmt->fetch();
 
        if (!$ticket) respond(['error' => 'Ticket not found'], 404);
 
        // Regular users can only see their own tickets
        if ($user['role'] === 'user' && $ticket['user_id'] != $user['id']) {
            respond(['error' => 'Forbidden'], 403);
        }
 
        // Get replies
        $stmt = $db->prepare("
            SELECT m.*, u.name AS author_name, u.avatar AS author_avatar, u.role AS author_role
            FROM messages m
            JOIN users u ON m.user_id = u.id
            WHERE m.ticket_id = ?
              AND (m.is_internal = 0 OR ? IN ('admin','agent'))
            ORDER BY m.created_at ASC
        ");
        $stmt->execute([$id, $user['role']]);
        $messages = $stmt->fetchAll();
 
        respond(['success' => true, 'ticket' => $ticket, 'messages' => $messages]);
 
    // POST /tickets.php?action=create
    case 'create':
        if ($method !== 'POST') respond(['error' => 'Method not allowed'], 405);
        $user = requireAuth();
        $db   = getDB();
 
        $subject     = trim($body['subject'] ?? '');
        $description = trim($body['description'] ?? '');
        $priority    = $body['priority'] ?? 'medium';
        $categoryId  = !empty($body['category_id']) ? (int)$body['category_id'] : null;
 
        if (!$subject || !$description) {
            respond(['error' => 'Subject and description are required'], 422);
        }
 
        $validPriorities = ['low', 'medium', 'high'];
        if (!in_array($priority, $validPriorities)) $priority = 'medium';
 
        // Generate ticket number
        $stmt = $db->query("SELECT COUNT(*) FROM tickets");
        $count = (int)$stmt->fetchColumn();
        $ticketNumber = 'TKT-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT);
 
        $stmt = $db->prepare("
            INSERT INTO tickets (ticket_number, subject, description, priority, category_id, user_id)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$ticketNumber, $subject, $description, $priority, $categoryId, $user['id']]);
        $ticketId = $db->lastInsertId();
 
        // Send confirmation email to user
        require_once __DIR__ . '/mailer.php';
        $stmt = $db->prepare("SELECT name, email FROM users WHERE id = ?");
        $stmt->execute([$user['id']]);
        $userInfo = $stmt->fetch();

        sendMail(
        $userInfo['email'],
        $userInfo['name'],
        "Ticket Created - {$ticketNumber}",
        "Your ticket <strong>{$ticketNumber}</strong> has been submitted successfully.<br><br>
        <strong>Subject:</strong> {$subject}<br>
        <strong>Priority:</strong> {$priority}<br><br>
        Our support team will get back to you as soon as possible."
        );
        respond([
            'success'       => true,
            'ticket_id'     => $ticketId,
            'ticket_number' => $ticketNumber,
            'message'       => 'Ticket created successfully'
        ], 201);
 
    // PUT /tickets.php?action=update&id=X
    case 'update':
        if ($method !== 'PUT' && $method !== 'POST') respond(['error' => 'Method not allowed'], 405);
        $user = requireRole(['admin', 'agent']);
        $db   = getDB();
 
        $allowed = ['status', 'priority', 'assigned_to', 'category_id'];
        $sets    = [];
        $params  = [];
 
        foreach ($allowed as $field) {
            if (isset($body[$field])) {
                $sets[]   = "$field = ?";
                $params[] = $body[$field] ?: null;
            }
        }
 
        if (empty($sets)) respond(['error' => 'No fields to update'], 422);
 
 
        $params[] = $id;
        $sql = "UPDATE tickets SET " . implode(', ', $sets) . " WHERE id = ?";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
 
        respond(['success' => true, 'message' => 'Ticket updated']);
 
    // DELETE /tickets.php?action=delete&id=X
    case 'delete':
        $user = requireRole(['admin']);
        $db   = getDB();
 
        $stmt = $db->prepare("DELETE FROM tickets WHERE id = ?");
        $stmt->execute([$id]);
 
        respond(['success' => true, 'message' => 'Ticket deleted']);
 
    // GET /tickets.php?action=stats
    case 'stats':
        requireRole(['admin', 'agent']);
        $db = getDB();
 
        $stats = [];
 
        $stmt = $db->query("SELECT status, COUNT(*) as count FROM tickets GROUP BY status");
        $byStatus = [];
        foreach ($stmt->fetchAll() as $row) $byStatus[$row['status']] = $row['count'];
        $stats['by_status'] = $byStatus;
 
        $stmt = $db->query("SELECT priority, COUNT(*) as count FROM tickets GROUP BY priority");
        $byPriority = [];
        foreach ($stmt->fetchAll() as $row) $byPriority[$row['priority']] = $row['count'];
        $stats['by_priority'] = $byPriority;
 
        $stmt = $db->query("SELECT COUNT(*) FROM tickets");
        $stats['total'] = (int)$stmt->fetchColumn();
 
        $stmt = $db->query("SELECT COUNT(*) FROM users WHERE role = 'user'");
        $stats['total_users'] = (int)$stmt->fetchColumn();
 
        $stmt = $db->query("SELECT COUNT(*) FROM tickets WHERE DATE(created_at) = CURDATE()");
        $stats['today'] = (int)$stmt->fetchColumn();
 
// Weekly data (last 7 days)
$weekly = [];
$days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $dayName = date('D', strtotime("-$i days"));

    $stmt = $db->prepare("SELECT COUNT(*) FROM tickets WHERE DATE(created_at) = ?");
    $stmt->execute([$date]);
    $total = (int)$stmt->fetchColumn();

    $stmt = $db->prepare("SELECT COUNT(*) FROM tickets WHERE DATE(created_at) = ? AND status = 'closed'");
    $stmt->execute([$date]);
    $closed = (int)$stmt->fetchColumn();

    $stmt = $db->prepare("SELECT COUNT(*) FROM tickets WHERE DATE(created_at) = ? AND status = 'in_progress'");
    $stmt->execute([$date]);
    $waiting = (int)$stmt->fetchColumn();

    $weekly[] = ['day' => $dayName, 'total' => $total, 'closed' => $closed, 'waiting' => $waiting];
}
$stats['weekly'] = $weekly;
        respond(['success' => true, 'stats' => $stats]);
 
    default:
        respond(['error' => 'Unknown action'], 404);
}