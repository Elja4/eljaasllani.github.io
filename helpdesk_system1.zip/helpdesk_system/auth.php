<?php
// AUTH API
require_once __DIR__ . '/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$body   = json_decode(file_get_contents('php://input'), true) ?? [];

switch ($action) {

    // POST /auth.php?action=login
    case 'login':
        if ($method !== 'POST') respond(['error' => 'Method not allowed'], 405);

        $email    = trim($body['email'] ?? '');
        $password = $body['password'] ?? '';

        if (!$email || !$password) {
            respond(['error' => 'Email and password are required'], 422);
        }

        $db   = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password'])) {
            respond(['error' => 'Invalid email or password'], 401);
        }

        // Store in session
        $_SESSION['user'] = [
            'id'    => $user['id'],
            'name'  => $user['name'],
            'email' => $user['email'],
            'role'  => $user['role'],
            'avatar'=> $user['avatar'],
        ];

        respond([
            'success' => true,
            'user'    => $_SESSION['user'],
            'message' => 'Login successful'
        ]);

    // POST /auth.php?action=register
    case 'register':
        if ($method !== 'POST') respond(['error' => 'Method not allowed'], 405);

        $name     = trim($body['name'] ?? '');
        $email    = trim($body['email'] ?? '');
        $password = $body['password'] ?? '';

        $role = $body['role'] ?? 'user';
        // Only allow valid roles
        if (!in_array($role, ['user', 'agent', 'admin'])) $role = 'user';

        if (!$name || !$email || !$password) {
            respond(['error' => 'All fields are required'], 422);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            respond(['error' => 'Invalid email address'], 422);
        }
        if (strlen($password) < 6) {
            respond(['error' => 'Password must be at least 6 characters'], 422);
        }

        $db   = getDB();
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            respond(['error' => 'Email already registered'], 409);
        }

        $avatars = ['😊','🙂','😎','🤓','👨','👩','🧑','👦','👧'];
        $avatar  = $avatars[array_rand($avatars)];
        $hash    = password_hash($password, PASSWORD_BCRYPT);

        $stmt = $db->prepare(
        "INSERT INTO users (name, email, password, role, avatar) VALUES (?, ?, ?, ?, ?)"
        );
       $stmt->execute([$name, $email, $hash, $role, $avatar]);
       $userId = $db->lastInsertId();


        $_SESSION['user'] = [
            'id'    => $userId,
            'name'  => $name,
            'email' => $email,
            'role'  => $role,
            'avatar'=> $avatar,
        ];

        respond(['success' => true, 'user' => $_SESSION['user'], 'message' => 'Registration successful']);


    // POST /auth.php?action=logout
    case 'logout':
        session_destroy();
        respond(['success' => true, 'message' => 'Logged out']);

    // GET /auth.php?action=me
    case 'me':
        if (empty($_SESSION['user'])) {
            respond(['authenticated' => false]);
        }
        respond(['authenticated' => true, 'user' => $_SESSION['user']]);

    default:
        respond(['error' => 'Unknown action'], 404);
}