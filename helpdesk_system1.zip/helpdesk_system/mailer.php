<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/PHPMailer/src/Exception.php';
require_once __DIR__ . '/PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

define('MAIL_HOST',     'smtp.gmail.com');
define('MAIL_PORT',     587);
define('MAIL_USERNAME', 'lorena.bakia@fshnstudent.info');     
define('MAIL_PASSWORD', 'vwhedwmdeehxmalt');  
define('MAIL_FROM',     'lorena.bakia@fshnstudent.info');     
define('MAIL_FROMNAME', 'DeskFlow Support');

function sendMail(string $toEmail, string $toName, string $subject, string $body): bool {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = MAIL_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = MAIL_USERNAME;
        $mail->Password   = MAIL_PASSWORD;
        $mail->SMTPSecure = 'tls';
        $mail->Port       = MAIL_PORT;

        $mail->setFrom(MAIL_FROM, MAIL_FROMNAME);
        $mail->addAddress($toEmail, $toName);

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = emailTemplate($subject, $body);
        $mail->AltBody = strip_tags($body);

        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}

function emailTemplate(string $title, string $content): string {
    return "
    <div style='font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#f3f5f7;padding:20px'>
        <div style='background:#13151c;border-radius:12px;padding:30px;color:#e8eaf0'>
            <div style='font-size:24px;font-weight:700;margin-bottom:20px'>
                🎯 DeskFlow
            </div>
            <div style='background:#1a1d27;border-radius:8px;padding:20px;margin-bottom:20px'>
                <h2 style='color:#e8eaf0;margin:0 0 14px'>{$title}</h2>
                <div style='color:#8b8fa8;line-height:1.6'>{$content}</div>
            </div>
            <div style='font-size:12px;color:#565a72;text-align:center'>
                This is an automated message from DeskFlow Helpdesk System
            </div>
        </div>
    </div>";
}