<?php
// CATEGORIES API
require_once __DIR__ . '/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$body   = json_decode(file_get_contents('php://input'), true) ?? [];

switch ($action) {

    case 'list':
        requireAuth();
        $db   = getDB();
        $stmt = $db->query("SELECT * FROM categories ORDER BY name");
        respond(['success' => true, 'categories' => $stmt->fetchAll()]);

    case 'create':
        requireRole(['admin']);
        $db   = getDB();
        $name = trim($body['name'] ?? '');
        if (!$name) respond(['error' => 'Name is required'], 422);

        $stmt = $db->prepare("INSERT INTO categories (name, color, icon) VALUES (?, ?, ?)");
        $stmt->execute([$name, $body['color'] ?? '#6366f1', $body['icon'] ?? '🔧']);
        respond(['success' => true, 'id' => $db->lastInsertId()], 201);

    case 'delete':
        requireRole(['admin']);
        $db = getDB();
        $id = (int)($_GET['id'] ?? 0);
        $db->prepare("DELETE FROM categories WHERE id = ?")->execute([$id]);
        respond(['success' => true]);

    default:
        respond(['error' => 'Unknown action'], 404);
}