<?php
// USERS API
require_once __DIR__ . '/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$id     = (int)($_GET['id'] ?? 0);
$body   = json_decode(file_get_contents('php://input'), true) ?? [];

switch ($action) {

    case 'list':
        requireRole(['admin']);
        $db   = getDB();
        $stmt = $db->query("
            SELECT id, name, email, role, avatar, created_at,
                   (SELECT COUNT(*) FROM tickets WHERE user_id = users.id) AS ticket_count
            FROM users
            ORDER BY created_at DESC
        ");
        respond(['success' => true, 'users' => $stmt->fetchAll()]);

    case 'agents':
        requireAuth();
        $db   = getDB();
        $stmt = $db->query("SELECT id, name, avatar FROM users WHERE role IN ('admin','agent') ORDER BY name");
        respond(['success' => true, 'agents' => $stmt->fetchAll()]);

    case 'update_role':
        requireRole(['admin']);
        $db   = getDB();
        $role = $body['role'] ?? '';
        if (!in_array($role, ['user','agent','admin'])) respond(['error' => 'Invalid role'], 422);

        $stmt = $db->prepare("UPDATE users SET role = ? WHERE id = ?");
        $stmt->execute([$role, $id]);
        respond(['success' => true, 'message' => 'Role updated']);

    case 'delete':
        requireRole(['admin']);
        $db = getDB();

        // Prevent self-delete
        $currentUser = requireAuth();
        if ($currentUser['id'] == $id) respond(['error' => 'Cannot delete yourself'], 422);

        $db->prepare("DELETE FROM users WHERE id = ?")->execute([$id]);
        respond(['success' => true, 'message' => 'User deleted']);

    case 'profile':
        $user = requireAuth();
        $db   = getDB();

        $name  = trim($body['name'] ?? $user['name']);
        $email = trim($body['email'] ?? $user['email']);

        if (!empty($body['password'])) {
            if (strlen($body['password']) < 6) respond(['error' => 'Password min 6 chars'], 422);
            $hash = password_hash($body['password'], PASSWORD_BCRYPT);
            $stmt = $db->prepare("UPDATE users SET name=?, email=?, password=? WHERE id=?");
            $stmt->execute([$name, $email, $hash, $user['id']]);
        } else {
            $stmt = $db->prepare("UPDATE users SET name=?, email=? WHERE id=?");
            $stmt->execute([$name, $email, $user['id']]);
        }

        $_SESSION['user']['name']  = $name;
        $_SESSION['user']['email'] = $email;

        respond(['success' => true, 'message' => 'Profile updated']);

    default:
        respond(['error' => 'Unknown action'], 404);
}